
# Git Branching & Merging Hands-On Lab

## Objectives
- Explain branching and merging
- Explain creating branch and merge requests in GitLab

## What You’ll Learn
- How to create a branch, commit changes, and merge to master
- Using P4Merge to view visual differences

## Prerequisites
- Git and P4Merge installed
- A GitLab repo created
- Notepad++ configured as default editor

## Estimated Time
30 minutes

---

## 📌 Branching Instructions

### 1. Create and switch to a new branch
```bash
git checkout -b GitNewBranch
```

### 2. List all branches
```bash
git branch -a
```

### 3. Add new files
```bash
echo "This is content from GitNewBranch" > branchfile.txt
```

### 4. Commit changes
```bash
git add branchfile.txt
git commit -m "Add file in GitNewBranch"
```

### 5. Check branch status
```bash
git status
```

---

## 🔄 Merging Instructions

### 1. Switch back to master
```bash
git checkout master
```

### 2. See command-line differences
```bash
git diff master GitNewBranch
```

### 3. View visual differences using P4Merge
```bash
git difftool master GitNewBranch
```

(Ensure P4Merge is configured with `git config --global diff.tool p4merge`)

### 4. Merge the branch
```bash
git merge GitNewBranch
```

### 5. View merge log
```bash
git log --oneline --graph --decorate
```

### 6. Delete the branch
```bash
git branch -d GitNewBranch
git status
```

---

## 📝 GitLab Steps (Optional for GUI)
- Push branch: `git push origin GitNewBranch`
- Create Merge Request on GitLab via Web UI
