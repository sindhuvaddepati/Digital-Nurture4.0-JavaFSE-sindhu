
# Git Ignore Hands-On Lab

## Objectives
- Explain `.gitignore`
- Learn to ignore unwanted files using `.gitignore`

## What You’ll Learn
- How to ignore files and folders using Git
- Configure `.gitignore` properly

## Prerequisites
- Git setup on local machine
- Notepad++ integrated as default Git editor
- A local Git repo connected to GitLab

## Estimated Time
20 minutes

## Steps

### 1. Create a Git repository (if not already)
```bash
mkdir GitIgnoreDemo
cd GitIgnoreDemo
git init
```

### 2. Create unwanted files/folders
```bash
echo "This is a log file" > debug.log
mkdir logs
echo "Another log" > logs/server.log
```

### 3. Create `.gitignore` file
```bash
echo "*.log" > .gitignore
echo "logs/" >> .gitignore
```

### 4. Check Git status
```bash
git status
```
You should **not** see the `.log` files and `logs/` folder in the staging area.

### 5. Add, Commit, and Push (if required)
```bash
git add .
git commit -m "Add .gitignore to ignore logs"
git push origin master
```
