
# Git Hands-On Lab

## Objectives
Familiarize with Git commands: git init, git status, git add, git commit, git push, git pull.

## Steps Summary

### 1. Setup Git Configuration
```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
```

### 2. Make Notepad++ Default Editor
- Add Notepad++ to PATH (Environment Variables)
```bash
git config --global core.editor "'C:/Program Files/Notepad++/notepad++.exe' -multiInst -notabbar -nosession -noPlugin"
```

### 3. Initialize Git Project
```bash
mkdir GitDemo
cd GitDemo
git init
```

### 4. Create and Track File
```bash
echo "Welcome to Git" > welcome.txt
git add welcome.txt
git commit
```

### 5. Push to GitLab
```bash
git remote add origin https://gitlab.com/your-username/GitDemo.git
git push origin master
```
