Git Conflict Resolution Hands-On Lab (Git-T03-HOL_001)

Follow these steps in Git Bash:

1.  git status
2.  git checkout -b GitWork
3.  echo "<message>Hello from GitWork branch</message>" > hello.xml
4.  git add hello.xml
5.  git commit -m "Added hello.xml in GitWork branch"
6.  git checkout master
7.  echo "<message>Hello from master branch</message>" > hello.xml
8.  git add hello.xml
9.  git commit -m "Added hello.xml in master with different content"
10. git log --oneline --graph --decorate --all
11. git diff master GitWork
12. Use P4Merge or any 3-way merge tool for visualization
13. git merge GitWork
14. Resolve conflict using a 3-way merge tool
15. git add hello.xml
16. git commit -m "Resolved merge conflict"
17. echo "*.bak" >> .gitignore
18. git add .gitignore
19. git commit -m "Add backup file pattern to .gitignore"
20. git branch
21. git branch -d GitWork
22. git log --oneline --graph --decorate
