Git Cleanup and Push Back Hands-On Lab (Git-T03-HOL_002)

Follow these steps in Git Bash:

1.  git status
2.  git branch
3.  git pull origin master
4.  git add .
5.  git commit -m "Finalizing changes for Git-T03-HOL_002"
6.  git push origin master
7.  Check your remote GitHub repository to confirm changes were pushed
