package com.library1.repository;

public class BookRepository {
    public void displayBooks() {
        System.out.println("Repository: Showing book list...");
    }
}
