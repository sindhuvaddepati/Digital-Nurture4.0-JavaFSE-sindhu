package com.library1.service;

import com.library1.repository.BookRepository;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void showBooks() {
        System.out.println("Service: Calling repository...");
        bookRepository.displayBooks();
    }
}
