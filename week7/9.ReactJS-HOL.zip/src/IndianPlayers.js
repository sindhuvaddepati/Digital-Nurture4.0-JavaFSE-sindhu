import React from 'react';

const IndianPlayers = () => {
  const team = ['Virat', 'Rohit', 'Rahul', 'Pant', 'Hardik', 'Bumrah'];
  const [odd1, even1, odd2, even2, odd3, even3] = team;

  const T20players = ['Virat', 'Rohit', 'Pandya'];
  const RanjiTrophy = ['Rahane', 'Pujara', 'Saha'];
  const mergedPlayers = [...T20players, ...RanjiTrophy];

  return (
    <div>
      <h2>Destructured Odd and Even Team Players:</h2>
      <p>Odd Team: {odd1}, {odd2}, {odd3}</p>
      <p>Even Team: {even1}, {even2}, {even3}</p>

      <h2>Merged Player List:</h2>
      <ul>
        {mergedPlayers.map((player, index) => (
          <li key={index}>{player}</li>
        ))}
      </ul>
    </div>
  );
};

export default IndianPlayers;
