import React from 'react';

function App() {
  const heading = <h1 style={{ textAlign: 'center', color: '#333' }}>🏢 Office Space Rentals</h1>;

  const officeList = [
    { name: 'Tech Park View', rent: 55000, address: 'Gachibowli, Hyderabad', image: 'https://via.placeholder.com/250' },
    { name: 'Skyline Towers', rent: 72000, address: 'Hitech City, Hyderabad', image: 'https://via.placeholder.com/250' },
    { name: 'Urban Square', rent: 48000, address: 'Madhapur, Hyderabad', image: 'https://via.placeholder.com/250' },
    { name: 'CityScape Hub', rent: 83000, address: 'Banjara Hills, Hyderabad', image: 'https://via.placeholder.com/250' }
  ];

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '20px' }}>
      {heading}
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '20px' }}>
        {officeList.map((office, index) => (
          <div key={index} style={{ border: '1px solid #ccc', borderRadius: '10px', padding: '15px', width: '250px', textAlign: 'center' }}>
            <img src={office.image} alt={office.name} style={{ width: '100%', borderRadius: '8px' }} />
            <h3>{office.name}</h3>
            <p><strong>Address:</strong> {office.address}</p>
            <p style={{ color: office.rent < 60000 ? 'red' : 'green' }}><strong>Rent:</strong> ₹{office.rent}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
