import React, { useState } from 'react';
import GuestPage from './components/GuestPage';
import UserPage from './components/UserPage';
import FlightDetails from './components/FlightDetails';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  let content;
  if (isLoggedIn) {
    content = <UserPage onLogout={() => setIsLoggedIn(false)} />;
  } else {
    content = <GuestPage onLogin={() => setIsLoggedIn(true)} />;
  }

  return (
    <div className="App">
      <h1>Ticket Booking App</h1>
      <FlightDetails />
      {content}
    </div>
  );
}

export default App;
