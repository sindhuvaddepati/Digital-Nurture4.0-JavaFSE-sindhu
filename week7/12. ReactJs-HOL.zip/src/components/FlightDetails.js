import React from 'react';

function FlightDetails() {
  return (
    <div>
      <h3>Flight Details</h3>
      <ul>
        <li>Flight: AI202 | From: Delhi | To: Mumbai</li>
        <li>Flight: BA304 | From: London | To: New York</li>
        <li>Flight: EK505 | From: Dubai | To: Hyderabad</li>
      </ul>
    </div>
  );
}

export default FlightDetails;
