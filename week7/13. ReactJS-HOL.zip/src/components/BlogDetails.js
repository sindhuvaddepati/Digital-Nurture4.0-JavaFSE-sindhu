import React from 'react';

function BlogDetails() {
  const blogs = [
    { id: 101, title: 'React Basics', writer: 'John' },
    { id: 102, title: 'Advanced React', writer: 'Jane' },
  ];

  return (
    <div>
      <h2>Blog Details</h2>
      <ul>
        {blogs.map(blog => (
          <li key={blog.id}>
            {blog.title} - written by {blog.writer}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default BlogDetails;
