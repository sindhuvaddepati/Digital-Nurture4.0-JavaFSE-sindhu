import React from 'react';

function CourseDetails() {
  const courses = [
    { id: 'C01', name: 'ReactJS' },
    { id: 'C02', name: 'NodeJS' },
    { id: 'C03', name: 'MongoDB' }
  ];

  return (
    <div>
      <h2>Course Details</h2>
      <ul>
        {courses.map(course => (
          <li key={course.id}>{course.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default CourseDetails;
