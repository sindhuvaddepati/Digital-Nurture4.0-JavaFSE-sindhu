import React, { useState } from 'react';
import BookDetails from './components/BookDetails';
import BlogDetails from './components/BlogDetails';
import CourseDetails from './components/CourseDetails';

function App() {
  const [show, setShow] = useState('book');

  // Method 1: Using if-else
  let content;
  if (show === 'book') {
    content = <BookDetails />;
  } else if (show === 'blog') {
    content = <BlogDetails />;
  } else {
    content = <CourseDetails />;
  }

  return (
    <div className="App">
      <h1>Blogger App</h1>
      <button onClick={() => setShow('book')}>Show Book Details</button>
      <button onClick={() => setShow('blog')}>Show Blog Details</button>
      <button onClick={() => setShow('course')}>Show Course Details</button>

      {/* Conditional Rendering Method 2: Ternary operator */}
      {show === 'book' ? <BookDetails /> :
       show === 'blog' ? <BlogDetails /> : <CourseDetails />}

      {/* Conditional Rendering Method 3: Logical && operator */}
      {show === 'book' && <BookDetails />}
      {show === 'blog' && <BlogDetails />}
      {show === 'course' && <CourseDetails />}

      {/* Method 4: Element variable (already demonstrated above as `content`) */}
      <hr />
      <h3>Rendered via element variable:</h3>
      {content}
    </div>
  );
}

export default App;
