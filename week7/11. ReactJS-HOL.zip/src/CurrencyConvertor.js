import React, { Component } from 'react';

class CurrencyConvertor extends Component {
  constructor() {
    super();
    this.state = {
      rupees: '',
      euros: ''
    };
  }

  handleChange = (e) => {
    this.setState({ rupees: e.target.value });
  }

  handleSubmit = (e) => {
    e.preventDefault();
    const euroRate = 0.011; // 1 INR ≈ 0.011 Euro
    const euros = (this.state.rupees * euroRate).toFixed(2);
    this.setState({ euros });
  }

  render() {
    return (
      <div>
        <h2>💱 Currency Converter</h2>
        <form onSubmit={this.handleSubmit}>
          <input
            type="number"
            placeholder="Enter amount in INR"
            value={this.state.rupees}
            onChange={this.handleChange}
          />
          <button type="submit">Convert</button>
        </form>
        {this.state.euros && <p>Equivalent in Euros: €{this.state.euros}</p>}
      </div>
    );
  }
}

export default CurrencyConvertor;
