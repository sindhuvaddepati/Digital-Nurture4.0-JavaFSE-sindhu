import React, { Component } from 'react';
import CurrencyConvertor from './CurrencyConvertor';

class App extends Component {
  constructor() {
    super();
    this.state = {
      count: 0
    };
    this.increment = this.increment.bind(this);
    this.sayHello = this.sayHello.bind(this);
    this.increaseHandler = this.increaseHandler.bind(this);
    this.sayWelcome = this.sayWelcome.bind(this);
    this.handlePress = this.handlePress.bind(this);
  }

  increment() {
    this.setState(prevState => ({ count: prevState.count + 1 }));
  }

  decrement = () => {
    this.setState(prevState => ({ count: prevState.count - 1 }));
  }

  sayHello() {
    console.log("Hello! Welcome to React Events.");
  }

  increaseHandler() {
    this.increment();
    this.sayHello();
  }

  sayWelcome(message) {
    alert(message);
  }

  handlePress(e) {
    alert("I was clicked");
    console.log("Synthetic event type:", e.type);
  }

  render() {
    return (
      <div style={{ padding: '20px', fontFamily: 'Arial' }}>
        <h1>🎯 React Event Examples</h1>
        <h2>Counter: {this.state.count}</h2>
        <button onClick={this.increaseHandler}>Increment</button>
        <button onClick={this.decrement}>Decrement</button>
        <br /><br />
        <button onClick={() => this.sayWelcome('Welcome to the Event Handling App!')}>Say Welcome</button>
        <br /><br />
        <button onClick={this.handlePress}>OnPress</button>
        <br /><br />
        <CurrencyConvertor />
      </div>
    );
  }
}

export default App;
